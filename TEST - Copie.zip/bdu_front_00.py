from flask import Flask,render_template, request, jsonify, redirect, url_for
import json
import housni_tools  as ht


app = Flask(__name__)
# ========================================================================= PROFILER
links=['/hac',                      #links[0]
       '/dashboard',                #links[1]
       '/hae',                      #links[2]
       '/haf',                      #links[3]
       '/dropdown',                 #links[4]
       '/h2',                       #links[5]
       '/cards',                    #links[6]
       '/hae_',                     #links[7]
       '/',                         #links[8]
       '/had',                      #links[9]
       '/housni',                   #links[10]
       '/update_element',           #links[11]
       '/requette',                 #links[12]
       ]

@app.route('/recherche', methods=['POST'])
def chercher():
    if request.method == 'POST':
        data = dict(request.form)
        print(data)
        if "recherche" in data:
            if "/"+data["recherche"] in links:
               return redirect("/"+data["recherche"])
    return '', 204
# ========================================================================= PLOTLY

# @app.route(links[0])
# def housni_ac_plotly_line():
    
#     return render_template('housni_ac_plotly_line.html')

@app.route(links[1])
def dashboard():
    housni_bar_graphe   = ht.housni_bar_graphe(barres={"x" : ["off", "odr", "mdr"],"y" : [250,250*3,250*9]})
    housni_line_graphe  = ht.housni_line_graphe(values={"x" : [2024, 2025, 2026, 2027, 2028],"y" : [200, 450, 523, 550, 580], "title": "prévision du déficit des cinq prochaines années","x_axis":"années","y_axis":"déficits prévu"})
    housni_regions_maroc= ht.housni_regions_maroc()
    return render_template("housni_ad_plotly_barre_graphe.html",
                           plot_bar_html=housni_bar_graphe,
                           plot_line_html=housni_line_graphe,
                           regions=housni_regions_maroc
                           )

#========================================================================== GRID //////////////////////////////////////////
@app.route(links[2], methods=['POST','GET'])
def housni_ae_grid():
    tableau= {
        "table_name" : "tableau test",
        "cols" : ['Nom', 'Âge', 'Email'],
        "data" :[
            ['Alice', '25', 'alice@example.com'],
            ['Bob', '30', 'bob@example.com'],
            ['Charlie', '35', 'charlie@example.com']
        ]}
    return render_template('housni_ae_grid.html',tableau=tableau, message="ach hadchi")

#========================================================================== POPUP housni_af_popup.html
@app.route(links[3])
def housni_af_popup():
    return render_template('housni_af_popup.html')


#========================================================================== DROPDOWN

#dropdown
@app.route(links[4], methods=['POST'])
def housni_dropdown():
    if request.method == 'POST':
        data = dict(request.form)
        print( json.dumps(data,indent=2))
        if "1.1" in data:
            return render_template("housni_af_popup.html")
    return render_template("housni_ab.html")

@app.route(links[5], methods=['POST','GET'])
def housni_pagedd():
    return render_template("housni_ab.html")

#========================================================================== UPDATE JAVASCRIPT
@app.route(links[6])
def housni_cards():
    return render_template('housni_cards.html')


#========================================================================== UPDATE JAVASCRIPT

@app.route(links[7])
def housni_ae_grid_javascript_update():
    name = "John Doe"  # Exemple de valeur à passer au template
    return render_template('housni_ae_grid.html', name=name)


#========================================================================== 

@app.route(links[8])
def yahya():
    return render_template("yahya_index.html")

@app.route(links[9])
def housni_ad_plotly_barre_graphe():
    return render_template("yahya_corps_dashboard.html")


@app.route(links[10], methods=['GET'])
def housni():
    return render_template("housni_aa.html")

@app.route(links[11], methods=['POST'])
def update_element():
    # Logique pour mettre à jour l'élément spécifique
    updated_content = "Nouveau contenu de l'élément : insertion possible"

    return jsonify({'updated_content': updated_content})

#========================================================================== REQUETTE
@app.route(links[12], methods=['POST'])
def requette():
    if request.method == 'POST':
        data = dict(request.form)
        print( json.dumps(data,indent=2))
        if "1.1" in data:
            return render_template("housni_af_popup.html")
    return '',204

if __name__ == "__main__":
    app.run(debug=True)